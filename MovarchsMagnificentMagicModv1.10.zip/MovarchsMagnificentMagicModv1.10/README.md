# MorvarchsManificentMagicMod

A mod adding a multitude of crosspath spells dominions, especially focusing on crosspaths that didn't have much love already.

Designed to work with DE, hence the included merged version, though I don't extensively test the merged patch.

You can find a description of all spells added here: https://docs.google.com/document/d/1vknmIBjRqq0X45gwAutuuUwK9F_4I7GVuaNh3A2lDUQ/edit?usp=sharing!